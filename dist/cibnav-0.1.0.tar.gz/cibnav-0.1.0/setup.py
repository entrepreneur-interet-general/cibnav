# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['src', 'src.dags']

package_data = \
{'': ['*'], 'src': ['modeles/*']}

install_requires = \
['pandas>=1.5.3,<2.0.0',
 'psycopg2>=2.9.5,<3.0.0',
 'python-dotenv>=1.0.0,<2.0.0']

setup_kwargs = {
    'name': 'cibnav',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Quentin Loridant',
    'author_email': 'quentin.loridant@multi.coop',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
